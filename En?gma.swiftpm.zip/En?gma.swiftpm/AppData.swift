//
//  File.swift
//  Quiz
//
//  Created by Davide Belardi on 15/04/22.
//

import Foundation
import AVFoundation

var audio : AVPlayer!

class AppData : ObservableObject {
    
    func backgroundMusic() {
        let url = Bundle.main.url(forResource: "InquisiveOrchestra", withExtension: "mp3")
        audio = AVPlayer.init(url: url!)
        audio.volume = 0.1
        audio.seek(to: .zero)
        audio.play()

    }
 
}

