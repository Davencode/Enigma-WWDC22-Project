import SwiftUI
import AVFoundation

struct ContentView: View {
            
    var audio : AVPlayer!

    @State var answer1 : Bool = false
    @State var answer2 : Bool = false
    @State var answer3 : Bool = false
    
    var body: some View {
        
        NavigationView{
            
        ZStack{
            Image("BackgroundMain")
                .resizable()
                .ignoresSafeArea()
            
            VStack(spacing: 60.0) {
                
                Spacer()

                VStack{
                    NavigationLink(destination: Quiz3(solved3: $answer3)){
                        Image("icon")
                            .resizable()
                            .frame(width: 130, height: 200)
                            .padding(50)
                            .padding(.top, 30)
                            .scaledToFit()
                            .rotationEffect(Angle(degrees: 9.0))
                    }.buttonStyle(FlatLinkStyle()) 
                    
                }.frame(width: UIScreen.main.bounds.width)
                
                Spacer()
                
                VStack{
                    HStack{
                        
                        NavigationLink(destination: Quiz2(solved2: $answer2)){
                            Image("icon")
                                .resizable()
                                .frame(width: 130, height: 200)
                                .padding(50)
                                .scaledToFit()
                                .padding(.leading, 50)
                                .rotationEffect(Angle(degrees: -9.0))
                        }.buttonStyle(FlatLinkStyle())
                        
                        Spacer()
                        
                    }
                }
                
                VStack{
                    HStack{
                        Spacer()
                        NavigationLink(destination: Quiz1(solved1: $answer1)){
                                Image("icon")
                                    .resizable()
                                    .frame(width: 130, height: 200)
                                    .padding(70)
                                    .scaledToFit()
                                    .rotationEffect(Angle(degrees: 9.0))
                            }.buttonStyle(FlatLinkStyle())
                            
                        
                    }
                
                }
                
                Spacer()
                Spacer()
                Spacer()
                
            }
    
            if answer1 == true && answer2 == true && answer3 == true {
                ZStack{
                    Rectangle()
                        .foregroundColor(.black.opacity(0.4))
                        .frame(width: UIScreen.main.bounds.width)
                        .ignoresSafeArea()
                    
                    NavigationLink {
                        GuessTheRiddle()
                    } label: {
                        Text("Give the final solution")
                            .bold()
                    }.frame(width: 330, height: 40)
                        .font(.system(size: 30))
                        .background(.yellow)
                        .foregroundColor(.black)
                        .cornerRadius(20)
                }
            }
        }
            
        }.navigationBarHidden(true)
            .accentColor(.white)
            .navigationViewStyle(.stack)
        
            
   
    }
    
}


struct FlatLinkStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
    }
}


