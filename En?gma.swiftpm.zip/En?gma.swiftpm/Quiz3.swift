//
//  File.swift
//  Quiz
//
//  Created by Davide Belardi on 12/04/22.
//

import SwiftUI

struct Quiz3: View {
    
    @State var verify_question : Bool = false
    @State var verify_rightAnswer : Bool = false
    @State var verify_wrongAnswer : Bool = false
    
    @Binding var solved3 : Bool
    
    @State private var timeRemaining = 60
    
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    @Environment(\.scenePhase) var scenePhase
    @State private var isActive = true

    var body: some View {
    
        ZStack{
           Image("En?gmaBackground")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .ignoresSafeArea()
               
        
        VStack{
            
            Text("Time: \(timeRemaining)")
                .font(.largeTitle)
                .foregroundColor(.white)
                .padding(.horizontal, 20)
                .padding(.vertical, 5)
                .background(.black.opacity(0.45))
                .clipShape(Capsule())
            
            Text("You will be surrounded and \n observed by a lot of people, what event is about?")
                .font(.system(size:30, weight: .medium))
                .foregroundColor(.white)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 20)

                .background(.black.opacity(0.65))
                .clipShape(Capsule())
            
            HStack{
                ZStack{
                    Button {
                        verify_question = true
                        verify_wrongAnswer = true
                        timeRemaining -= 18
                        if timeRemaining < 0 {
                            timeRemaining = 0
                        }
                    } label: {
                        ZStack{
                            Rectangle()
                                .foregroundColor(.yellow.opacity(0.9))
                                .cornerRadius(20)
                            VStack{
                                Text("🎂")
                                    .font(.system(size: 150))
                                Text("My Birthday")
                                    .foregroundColor(.black)
                                    .font(.system(size:30, weight: .medium))
                            }
                        }
                    }

                }
                
                ZStack{
                    Button {
                        verify_question = true
                        verify_wrongAnswer = true
                        timeRemaining -= 18
                        if timeRemaining < 0 {
                            timeRemaining = 0
                        }
                    } label: {
                        ZStack{
                            Rectangle()
                                .foregroundColor(.yellow.opacity(0.9))
                                .cornerRadius(20)
                            VStack{
                                Text("🍾")
                                    .font(.system(size: 150))
                                Text("End of the year")
                                    .foregroundColor(.black)
                                    .font(.system(size:30, weight: .medium))
                            }
                        }
                    }

                }
            }
            
            HStack{
                ZStack{
                    Button {
                        verify_question = true
                        verify_wrongAnswer = true
                        timeRemaining -= 18
                        if timeRemaining < 0 {
                            timeRemaining = 0
                        }
                    } label: {
                        ZStack{
                            Rectangle()
                                .foregroundColor(.yellow.opacity(0.9))        .cornerRadius(20)
                            VStack{
                                Text("🎉")
                                    .font(.system(size: 150))
                                Text("Festival")
                                    .foregroundColor(.black)
                                    .font(.system(size:30, weight: .medium))
                            }
                        }
                    }

                }

                ZStack{
                    Button {
                        verify_question = true
                        verify_rightAnswer = true
                        isActive = false
                        solved3 = true
                    } label: {
                        ZStack{
                           
                            Rectangle()
                                .foregroundColor(.yellow.opacity(0.9))
                                .cornerRadius(20)
                            
                            VStack{
                                Text("🎙")
                                    .font(.system(size: 150))
                                Text("Conference")
                                    .foregroundColor(.black)
                                    .font(.system(size:30, weight: .medium))
                            }
                        }
                    }

                }

            }
        }.padding()
                .padding(.bottom, 60)
                .onReceive(timer) { time in
                    guard isActive else { return }

                    if timeRemaining > 0 {
                        timeRemaining -= 1
                    }
                }.frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
                
            if verify_rightAnswer == true {
                
                Rectangle()
                    .foregroundColor(.black.opacity(0.4))
                    .frame(width: UIScreen.main.bounds.width)
                    .ignoresSafeArea()
                
            
                    ZStack{
                        Rectangle()
                            .foregroundColor(.green)
                            .frame(width: UIScreen.main.bounds.width / 1.5, height: UIScreen.main.bounds.height / 2)
                            .cornerRadius(20)
                        VStack{
                            Image(systemName: "checkmark.circle")
                                .resizable()
                                .frame(width: 180, height: 180)
                                .shadow(radius: 30)
                            Text("Congrats! that's right")
                                .font(.system(size: 40, weight: .bold))
                                .padding()
                            Text("Tap \"back\" to go in the riddle line")
                                .font(.system(size: 20, weight: .medium))
                        }
                            
                    }

                
                                    
            }
            
            if verify_wrongAnswer == true && timeRemaining > 0 {
                ZStack{
                    Rectangle()
                        .foregroundColor(.black.opacity(0.4))
                        .frame(width: UIScreen.main.bounds.width)
                        .ignoresSafeArea()
                    Rectangle()
                        .foregroundColor(.red)
                        .frame(width: UIScreen.main.bounds.width / 1.5, height: UIScreen.main.bounds.height / 2)
                        .onTapGesture {
                            verify_wrongAnswer = false
                        }
                        .cornerRadius(20)
                    VStack{
                        Image(systemName: "xmark.circle")
                            .resizable()
                            .frame(width: 180, height: 180)
                            .shadow(radius: 30)
                        Text("Oh no! it's not right")
                            .font(.system(size: 30, weight: .bold))
                            .padding()
                           
                        Text("Choose another answer, be careful with the time")
                            .font(.system(size: 20, weight: .medium))
                    }
                }.onTapGesture {
                    verify_wrongAnswer = false
                }
            }
            
            //condition to be game over
            if timeRemaining == 0 && verify_rightAnswer == false {
                
                ZStack{
                    Rectangle()
                        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
                        .foregroundColor(.black.opacity(0.8))
                        .ignoresSafeArea()
                //Vstacks to contain display area game over
                
                    VStack{
                    //area text game over
                        Text("Oh no, it seems that you haven't solved \n on time this En?gma, do you wish to :")
                        .font(.system(size:30, weight: .medium))
                        .frame(width: 600, height: 200)
                        
                    HStack{
                        
                        //area button Retry
                        Button {
                            
                        } label: {
                            Text("Retry")
                                .font(.system(size:30, weight: .medium))
                                .frame(width: 200, height: 100)
                                .foregroundColor(.black)
                                .background(.green)
                                .cornerRadius(10)
                                .onTapGesture {
                                    timeRemaining = 60
                                    verify_wrongAnswer = false
                                }
                                .padding(.bottom, 30)

                        }
                        
                        //area button return to en?mga
                        NavigationLink {
                            ContentView()
                        } label: {
                            Text("Go back")
                                .frame(width: 200, height: 100)
                                .background(.yellow)
                                .foregroundColor(.black)
                                .cornerRadius(10)
                                .font(.system(size:30, weight: .medium))
                                .padding(.bottom, 30)

                        }
                        
                    }
                        
                    }.background(Color(red: 62 / 255, green: 17 / 255, blue: 242 / 255).opacity(0.7))
                        .cornerRadius(20)
                }
            }
            
        }
    }

}
