//
//  File.swift
//  Quiz
//
//  Created by Davide Belardi on 14/04/22.
//

import SwiftUI

struct OnBoarding: View {
    
    let appData = AppData()
    
    var body: some View {
    
        NavigationView{
        ZStack{
            
           Image("OnBoardingScreen")
                .resizable()
                .aspectRatio(contentMode: .fill)
                .ignoresSafeArea()
               
            VStack{
                Rectangle()
                    .foregroundColor(.black.opacity(0.0))
                    .frame(width: UIScreen.main.bounds.width/2, height: UIScreen.main.bounds.height/15)
                Rectangle()
                    .foregroundColor(.black.opacity(0.0))
                    .frame(width: UIScreen.main.bounds.width/2, height: UIScreen.main.bounds.height/15)
                Rectangle()
                    .foregroundColor(.black.opacity(0.0))
                    .frame(width: UIScreen.main.bounds.width/2, height: UIScreen.main.bounds.height/15)
                
                VStack{
                    ZStack{
                        Text("   Solve the enigma     🔎🧩   ")
                            .background(.black.opacity(0.6))
                            .cornerRadius(50)
                            .font(.system(size: 40, weight: .thin))
                            
                            .foregroundColor(.white)
                        
                            .frame(width: UIScreen.main.bounds.width/1, height: UIScreen.main.bounds.height/15)
                           
                        

                        
                    }.frame(width: 300, alignment: .center)
                        
                        ZStack{
                            Text("   Win the special reward    🏆  ")
                                .background(.black.opacity(0.6))
                                .cornerRadius(50)
                                .font(.system(size: 40, weight: .thin))
                                
                                .foregroundColor(.white)
                            
                                .frame(width: UIScreen.main.bounds.width/1, height: UIScreen.main.bounds.height/15)

                        }.frame(width: 300, alignment: .center)
                }.padding(.top, 50)
                
                
                NavigationLink(destination: ContentView()) {
                    ZStack{
                        Rectangle()
                            .foregroundColor(.yellow.opacity(0.7))
                            .frame(width: 240, height: 60)
                            .cornerRadius(50)
                        Text("Let's play!        ")
                            .foregroundColor(.black)
                            .background(.yellow)
                            .font(.system(size:35, weight: .medium))
                            .cornerRadius(30)
                       
                    }
                }

            }
            
        }.navigationBarHidden(true)
        }.navigationViewStyle(.stack)
        .onAppear(){
                appData.backgroundMusic()
            }
    }

}


