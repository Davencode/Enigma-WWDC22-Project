//
//  File.swift
//  En?gma
//
//  Created by Davide Belardi on 23/04/22.
//

import SwiftUI

struct GuessTheRiddle: View {
    
    @State var solution: String = ""

    @State var show_final_part : Bool = false
        
    var body: some View {

        ZStack{

        if show_final_part == false {
            
            Image("En?gmaBackground")
                 .resizable()
                 .aspectRatio(contentMode: .fill)
                 .ignoresSafeArea()
            
        VStack(alignment: .center) {
            
            Spacer()
            
            ZStack{
                Rectangle()
                    .frame(width: UIScreen.main.bounds.width, height: 500)
                    .foregroundColor(.black.opacity(0.6))

                VStack{
                    Text("Great! Now look the findings that \n we have found to solve the En?gma")
                        .font(.system(size : 25, weight: .light))
                        .padding()
                        .multilineTextAlignment(.center)

                    HStack{
                        
                        ZStack{
                            Rectangle()
                                .foregroundColor(.yellow)
                                .frame(width: 150, height: 40)
                                .cornerRadius(20)
                            Text("EARTH")
                                .bold()
                                .font(.system(size : 30))
                                .foregroundColor(.black)
                        }
                        ZStack{
                            Rectangle()
                                .foregroundColor(.yellow)
                                .frame(width: 200, height: 40)
                                .cornerRadius(20)
                            Text("DEVELOPER")
                                .bold()
                                .font(.system(size : 30))
                                .foregroundColor(.black)
                        }
                        
                        ZStack{
                            Rectangle()
                                .foregroundColor(.yellow)
                                .frame(width: 220, height: 40)
                                .cornerRadius(20)
                            Text("CONFERENCE")
                                .bold()
                                .font(.system(size : 30))
                                .foregroundColor(.black)

                        }
                    }
                    
                    Divider()
                        .foregroundColor(.white)
                        .background(.white)
                        .padding(.top)
                        .frame(width: UIScreen.main.bounds.width / 1.2)
                    Text("Who am I?")
                        .padding()
                        .font(.system(size : 25))
                    
                    Text("Write the final solution below")
                        .font(.system(size : 20))
                        .bold()
                    
                    NeumorphicStyleTextField(textField: TextField("Search...", text: $solution))
                        .frame(width: UIScreen.main.bounds.width / 1.5)

                    Button {
                        if solution == "WWDC" || solution == "World Wide Developers Conference" || solution == "world wide Developers Conference" || solution == "worldwidedevelopersconference" || solution == "World wide developers conference" || solution == "wwdc" || solution == "wwdc22" || solution == "WWDC22" || solution == "WorldWideDeveloperConference" || solution == "world wide Developers conference" || solution == "world wide developers Conference" || solution == "Wwdc" || solution == "Wwdc22" {
                            
                            show_final_part = true
                            
                        }
                    } label: {
                        Text("Claim the reward")
                            .bold()
                           
                    }.frame(width: 200, height: 50)
                        .background(.yellow)
                        .foregroundColor(.black)
                        .cornerRadius(20)
                        .padding()
                }
            }
            Spacer()
        }.padding(.horizontal, 50)
        
        } else {
            
            Image("Background")
                 .resizable()
                 .aspectRatio(contentMode: .fill)
                 .ignoresSafeArea()
            
            VStack{
                    ZStack{
                        Rectangle()
                            .frame(width: 500, height: 450)
                            .foregroundColor(.black.opacity(0.6))
                            .cornerRadius(20)
                        VStack{
                            Image("Trophy")
                                .resizable()
                                .frame(width: 200, height: 250)
                            Text("  CONGRATULATIONS!")
                                .foregroundColor(.white)
                                .bold()
                                .font(.system(size: 30))

                            Text("You've completed the EN?GMA")
                                .foregroundColor(.white)
                                .padding()
                                .font(.system(size: 30, weight: .thin))

                        }
                        
                           
                          
                        ZStack {
                            Circle()
                                .fill(Color.blue)
                                .frame(width: 12, height: 12)
                                .modifier(ParticlesModifier())
                                .offset(x: 0, y : -200)
                            
                            Circle()
                                .fill(Color.red)
                                .frame(width: 12, height: 12)
                                .modifier(ParticlesModifier())
                                .offset(x: 0, y : -200)
                            }
                        
                       
                    }
                }
            }
        }.navigationBarBackButtonHidden(true)
            .navigationBarHidden(true)
           
    }
}

//Struct for Firework + Particles with particle effect to simulate some final celebration
struct FireworkParticlesGeometryEffect : GeometryEffect {
    var time : Double
    var speed = Double.random(in: 20 ... 200)
    var direction = Double.random(in: -Double.pi ...  Double.pi)
    
    var animatableData: Double {
        get { time }
        set { time = newValue }
    }
    func effectValue(size: CGSize) -> ProjectionTransform {
        let xTranslation = speed * cos(direction) * time
        let yTranslation = speed * sin(direction) * time
        let affineTranslation =  CGAffineTransform(translationX: xTranslation, y: yTranslation)
        return ProjectionTransform(affineTranslation)
    }
}

struct ParticlesModifier: ViewModifier {
    @State var time = 0.10
    @State var scale = 0.1
    let duration = 5.0
    
    func body(content: Content) -> some View {
        ZStack {
            ForEach(0..<80, id: \.self) { index in
                content
                    .hueRotation(Angle(degrees: time * 80))
                    .scaleEffect(scale)
                    .modifier(FireworkParticlesGeometryEffect(time: time))
                    .opacity(((duration-time) / duration))
            }
        }
        .onAppear {
            withAnimation (.easeOut(duration: duration)) {
                self.time = duration
                self.scale = 1.0
            }
        }
    }
}

//Customized TextField
struct NeumorphicStyleTextField: View {
    var textField: TextField<Text>
    var body: some View {
        HStack {
            textField
            }
            .padding()
            .foregroundColor(.black)
            .background(Color.background)
            .cornerRadius(6)
            .shadow(color: Color.darkShadow, radius: 3, x: 2, y: 2)
            .shadow(color: Color.lightShadow, radius: 3, x: -2, y: -2)
            
        }
}

//Extension to the attribute Color. customized
extension Color {
    static let lightShadow = Color(red: 255 / 255, green: 255 / 255, blue: 255 / 255)
    static let darkShadow = Color(red: 163 / 255, green: 177 / 255, blue: 198 / 255)
    static let background = Color(red: 224 / 255, green: 229 / 255, blue: 236 / 255)
}
